#include "equipment.h"

Equipment::Equipment(QObject *parent) : QObject(parent) {}


bool Equipment::setUuid(QUuid uuid)
{
    if (m_uuid != uuid) {
        m_uuid = uuid;
        emit uuidChanged(m_uuid);
        return true;
    }
    return false;
}
