#pragma once

#include <QQmlEngine> // for QML_ELEMENT below.
#include <QDebug>
#include <QObject>
#include <QUrl>
#include <QUuid>
#include <QQuickItem>

class Equipment : public QObject
{
    Q_OBJECT
    QML_ELEMENT

    QUuid m_uuid = QUuid();
public:
    explicit Equipment(QObject *parent = nullptr);

    Q_PROPERTY(QUuid uuid READ uuid WRITE setUuid NOTIFY uuidChanged FINAL)
    QUuid uuid() { return m_uuid; }
    bool setUuid(QUuid uuid);

signals:
    void uuidChanged(QUuid uuid);

};
