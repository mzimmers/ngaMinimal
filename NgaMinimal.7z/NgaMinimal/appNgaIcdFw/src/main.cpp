#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QSysInfo>

int main(int argc, char *argv[])
{
    const QAnyStringView projectUri("NgaIcdFw");

    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;

    const QString platform = QSysInfo::productType();

    QString l_styleName;
    int rc;


    // going with Material style on Android for desired tab bar highlighting.
    // in Windows, some styles are problematic:
    // Universal doesn't honor the palette.buttonText setting in Roundbutton_custom
    // Basic, Fusion and Universal all ignore the accent setting in main.qml.
    l_styleName = (platform == "android")
                              ? "Material"
                              : (platform == "windows")
                                    ? "Universal"
                                    : "Fusion";
    QQuickStyle::setStyle(l_styleName);

    // make sure the QML engine starts correctly.
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.rootContext()->setContextProperty("styleName", l_styleName);
    engine.addImportPath(":/"); // enables Android to import from QRC root.
    engine.loadFromModule(projectUri, "Main");

    rc = app.exec();

    return rc;
}
