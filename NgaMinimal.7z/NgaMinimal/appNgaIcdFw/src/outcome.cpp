#include "outcome.h"

Outcome::Outcome(QObject *parent) : QObject(parent) {
    m_valveConfigurationList = ASSIGNED_VALVES;
}

Outcome::~Outcome() {}

bool Outcome::setUuid(QUuid uuid)
{
    if (m_uuid != uuid) {
        m_uuid = uuid;
        emit uuidChanged(m_uuid);
        return true;
    }
    return false;
}

bool Outcome::setValveConfigurationList(const QList<QUuid> &list)
{
    if (m_valveConfigurationList != list) {
        m_valveConfigurationList = list;
        emit valveConfigurationListChanged(m_valveConfigurationList);
        return true;
    }
    return false;
}

