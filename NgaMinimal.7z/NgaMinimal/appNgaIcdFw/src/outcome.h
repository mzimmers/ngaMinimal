#pragma once

#include <QQmlEngine>
#include <QUuid>

class Outcome : public QObject
{
    Q_OBJECT
    QML_ELEMENT

    QUuid m_uuid = QUuid();
    QList<QUuid> m_valveConfigurationList;
public:
    explicit Outcome(QObject *parent = nullptr);
    ~Outcome();

    Q_PROPERTY(QUuid uuid READ uuid WRITE setUuid NOTIFY uuidChanged FINAL)
    QUuid uuid() { return m_uuid; }
    bool setUuid(QUuid uuid);

    const static inline QList<QUuid> UNASSIGNED_VALVES = {
        QUuid::fromString("{fb4f3c69-312e-4399-8d80-ffabe2deab9f}"),
        QUuid::fromString("{fe93c695-7f7c-4af5-8ff8-8010fa6db546}")
    };
    Q_PROPERTY(QList<QUuid> unassignedValves MEMBER UNASSIGNED_VALVES CONSTANT)

    const static inline QList<QUuid> ASSIGNED_VALVES = {
        QUuid::fromString("{821856d4-deb1-4b55-9ba2-0fc4fee11ad2}"),
        QUuid::fromString("{68dbce5b-c0c3-4f95-a9f5-7db9f0351421}")
    };
    Q_PROPERTY(QList<QUuid> assignedValves MEMBER ASSIGNED_VALVES CONSTANT)

    Q_PROPERTY(QList<QUuid> valveConfigurationList READ valveConfigurationList WRITE setValveConfigurationList NOTIFY valveConfigurationListChanged FINAL)
    QList<QUuid> valveConfigurationList() { return m_valveConfigurationList; }
    bool setValveConfigurationList(const QList<QUuid> &list);

signals:
    void uuidChanged(QUuid uuid);
    void valveConfigurationListChanged(QList<QUuid> list);
};
